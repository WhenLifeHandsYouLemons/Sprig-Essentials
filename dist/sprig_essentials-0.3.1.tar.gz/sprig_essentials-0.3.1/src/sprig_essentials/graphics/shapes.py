import board

class Shape:
    def __init__(self) -> None:
        pass
