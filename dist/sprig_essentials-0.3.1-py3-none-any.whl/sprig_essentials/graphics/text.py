import board

class Text:
    def __init__(self) -> None:
        pass
